
/**
 * 
 */

/**
 * @author asuresh
 *
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Account {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Scanner sc = new Scanner(System.in);
		String url = "jdbc:mysql://localhost:3306/bank";
		String uname = "root";
		String pass = "root";
		String query,query1;
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uname, pass);
		Statement stmnt,stmnt1;
		ResultSet rs,rs1;
		System.out.println("Enetr the PersonId");
		int personId = sc.nextInt();
		System.out.println("Do you want to see last five transactions Click 1");
		System.out.println("If you want to transfer fund Click 2");
		int flag=sc.nextInt();
		if(flag==1)
		{
		System.out.println("Do you want to see last five transactions");
		System.out.println("If Yes Click 1");
		if (sc.nextInt() == 1) {
			query = "select * from transaction where PersonID=" + personId;
			stmnt = con.createStatement();
			rs = stmnt.executeQuery(query);
			System.out.println("Transaction ID" + " " + "Amount" + " " + "ReceiverId");
			while (rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getInt(3) + " " + rs.getInt(4));
			}
			stmnt.close();
		}
		query1 = "select Balance from Account where PersonID=" + personId;
		stmnt1 = con.createStatement();
		rs1 = stmnt1.executeQuery(query1);
		rs1.next();
		System.out.println("Available Balance: " + rs1.getInt(1));
		stmnt1.close();
		con.close();
		}
		else if(flag==2)
		{
			FundTransfer.transferFund(personId);
		}
		sc.close();
	}

}
