import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author suresh
 *
 */
public class FundTransfer {
	
	public static void transferFund(int personId) throws ClassNotFoundException, SQLException
	{
		Scanner sc = new Scanner(System.in);
		String url = "jdbc:mysql://localhost:3306/bank";
		String uname = "root";
		String pass = "root";
		String query;
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uname, pass);
		Statement stmnt;
		ResultSet rs;
		System.out.println("Enetr the ReciverId to whom you want to transfer fund");
		@SuppressWarnings("unused")
		int receiverId = sc.nextInt();
		System.out.println("Enter the Amount");
		int amount = sc.nextInt();
		query = "select Balance from Account where PersonID=" + personId;
		stmnt = con.createStatement();
		rs = stmnt.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);
		if(balance<amount)
		{
			System.out.println("You Account have insufficient balance");
		}
		else
		{
			balance=balance-amount;
			query = "update Account set Balance="+balance+" where PersonID="+personId+";";
			stmnt = con.createStatement();
			int count = stmnt.executeUpdate(query);
			if(count==1)
			{
				System.out.println("Succesfully Updated");
			}
			else
				System.out.println("Failed to update");
		}
		stmnt.close();
		con.close();
		sc.close();
	}
}
